from django.shortcuts import render

def table_view(request):
    number = request.GET.get('number', None)

    if number:
        try:
            number = int(number)
            table = [f"{number} x {i} = {number * i}" for i in range(1, 11)]
        except ValueError:
            table = None
    else:
        table = None

    return render(request, 'tableapp/table.html', {'table': table, 'number': number})
